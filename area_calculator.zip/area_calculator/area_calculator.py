from qgis.PyQt.QtCore import QSettings, QTranslator, QCoreApplication
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction
from qgis.core import QgsProject, QgsMapLayer
from shapely.ops import unary_union

from .area_calculator_dialog import AreaCalculatorDialog

import os.path
import geopandas as gpd


def process(save, layer):
	layer = QgsProject.instance().mapLayersByName(layer)[0]
	if layer.isValid() and layer.type() == QgsMapLayer.VectorLayer:
		features = [feature for feature in layer.getFeatures()]
		layer_geometries = [feature.geometry().asWkt() for feature in features]
		gdf = gpd.GeoDataFrame(geometry=gpd.GeoSeries.from_wkt(layer_geometries))

		buffered = gdf.geometry.buffer(0.25)
		union = unary_union(buffered)
		total_area = union.area

		print("Total Area:", total_area)
		with open(f"{save}/areas.txt", "a") as file:
			file.write(f"{layer.name()}: {total_area}\n")


class AreaCalculator:
	def __init__(self, iface):
		self.iface = iface
		self.plugin_dir = os.path.dirname(__file__)
		locale = QSettings().value('locale/userLocale')[0:2]
		locale_path = os.path.join(self.plugin_dir, 'i18n', 'AreaCalculator_{}.qm'.format(locale))
		if os.path.exists(locale_path):
			self.translator = QTranslator()
			self.translator.load(locale_path)
			QCoreApplication.installTranslator(self.translator)
		self.actions = []
		self.menu = self.tr(u'&Area Calculator')
		self.first_start = None

	def tr(self, message):
		return QCoreApplication.translate('AreaCalculator', message)

	def add_action(self, icon_path, text, callback, enabled_flag=True, add_to_menu=True, add_to_toolbar=True, status_tip=None, whats_this=None, parent=None):
		icon = QIcon(icon_path)
		action = QAction(icon, text, parent)
		action.triggered.connect(callback)
		action.setEnabled(enabled_flag)
		if status_tip is not None:
			action.setStatusTip(status_tip)
		if whats_this is not None:
			action.setWhatsThis(whats_this)
		if add_to_toolbar:
			self.iface.addToolBarIcon(action)
		if add_to_menu:
			self.iface.addPluginToMenu(self.menu, action)
		self.actions.append(action)
		return action

	def initGui(self):
		icon_path = ':/plugins/area_calculator/icon.png'
		self.add_action(icon_path, text=self.tr(u'That is it...'), callback=self.run, parent=self.iface.mainWindow())

	def unload(self):
		for action in self.actions:
			self.iface.removePluginMenu(self.tr(u'&Area Calculator'), action)
			self.iface.removeToolBarIcon(action)

	def run(self):
		self.dlg = AreaCalculatorDialog()
		self.dlg.buttonBox.accepted.connect(self.accept)
		self.dlg.buttonBox.rejected.connect(self.reject)
		self.dlg.show()

	def accept(self):
		inputs = self.dlg.get_inputs()
		save = inputs['save']
		layer = inputs['layer']
		self.dlg.accept()
		process(save, layer)

	def reject(self):
		self.dlg.reject()
