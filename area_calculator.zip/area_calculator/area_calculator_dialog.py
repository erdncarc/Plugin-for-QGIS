import os
from qgis.PyQt import uic
from qgis.core import QgsProject, QgsMapLayer
from qgis.PyQt.QtWidgets import QDialog, QLineEdit, QDialogButtonBox, QFileDialog, QPushButton, QComboBox


class AreaCalculatorDialog(QDialog):
	def __init__(self):
		super().__init__()
		uic.loadUi(os.path.join(os.path.dirname(__file__), 'area_calculator_dialog_base.ui'), self)

		self.layer_combo_box = self.findChild(QComboBox, 'layerComboBox')
		self.select_combo_box()

		self.save_button = self.findChild(QPushButton, 'saveButton')
		self.save_button.clicked.connect(self.select_save)

		self.buttonBox = self.findChild(QDialogButtonBox, 'buttonBox')
		self.buttonBox.accepted.connect(self.accept)
		self.buttonBox.rejected.connect(self.reject)

		QgsProject.instance().layerWasAdded.connect(self.select_combo_box)

	def select_save(self):
		folder_name = QFileDialog.getExistingDirectory(self, 'Folder', '')
		self.findChild(QLineEdit, 'save').setText(folder_name)

	def select_combo_box(self):
		self.layer_combo_box.clear()
		layers = QgsProject.instance().mapLayers().values()
		for layer in layers:
			if layer.type() == QgsMapLayer.VectorLayer:
				self.layer_combo_box.addItem(layer.name())

	def get_inputs(self):
		return {
			'save': self.findChild(QLineEdit, 'save').text(),
			'layer': self.findChild(QComboBox, 'layerComboBox').currentText(),
		}
