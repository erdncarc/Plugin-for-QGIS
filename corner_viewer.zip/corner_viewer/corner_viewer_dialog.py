import os
from qgis.PyQt import uic
from qgis.core import QgsProject, QgsMapLayer
from qgis.PyQt.QtWidgets import QDialog, QLineEdit, QCheckBox, QDialogButtonBox, QFileDialog, QPushButton, QComboBox

class CornerViewerDialog(QDialog):
    def __init__(self):
        super().__init__()
        uic.loadUi(os.path.join(os.path.dirname(__file__), 'corner_viewer_dialog_base.ui'), self)

        self.excel_button = self.findChild(QPushButton, 'excelButton')
        self.excel_button.clicked.connect(self.select_excel)

        self.folder_button = self.findChild(QPushButton, 'folderButton')
        self.folder_button.clicked.connect(self.select_folder)

        self.layer_combo_box = self.findChild(QComboBox, 'layerComboBox')
        self.select_combo_box()

        self.buttonBox = self.findChild(QDialogButtonBox, 'buttonBox')
        self.buttonBox.accepted.connect(self.accept)
        self.buttonBox.rejected.connect(self.reject)

        QgsProject.instance().layerWasAdded.connect(self.select_combo_box)

    def select_excel(self):
        file_name, _ = QFileDialog.getOpenFileName(self, 'Excel', '', 'Excel Files (*.xlsx *.xls)')
        self.findChild(QLineEdit, 'excel').setText(file_name)

    def select_folder(self):
        folder_name = QFileDialog.getExistingDirectory(self, 'Folder', '')
        self.findChild(QLineEdit, 'shp').setText(folder_name)

    def select_combo_box(self):
        self.layer_combo_box.clear()
        layers = QgsProject.instance().mapLayers().values()
        for layer in layers:
            if layer.type() == QgsMapLayer.VectorLayer:
                self.layer_combo_box.addItem(layer.name())

    def get_inputs(self):
        return {
            'excel': self.findChild(QLineEdit, 'excel').text(),
            'layer': self.findChild(QComboBox, 'layerComboBox').currentText(),
            'shp': self.findChild(QLineEdit, 'shp').text(),
            'save': self.findChild(QCheckBox, 'save').isChecked()
        }
