from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction
from qgis.PyQt.QtCore import QSettings, QTranslator, QCoreApplication

from .corner_viewer_dialog import CornerViewerDialog

import math
import os.path
import numpy as np
import pandas as pd
import geopandas as gpd
from shapely import Polygon, Point, LineString
from qgis.core import QgsProject, QgsMapLayer, QgsVectorLayer


def process_data(excel, layer, shp_path, save):
	length = {}
	df = pd.read_excel(os.path.join(os.path.dirname(__file__), excel))
	for i in df.index:
		length[df.iloc[i, 0]] = df.iloc[i, 1]

	all_data = {}
	layer = QgsProject.instance().mapLayersByName(layer)[0]
	if layer.isValid() and layer.type() == QgsMapLayer.VectorLayer:
		for feature in layer.getFeatures():
			if 'Undefined' in feature['Struct_Num'].split(' '): continue
			all_data[feature['Struct_Num']] = {
				'coordinates': {'x': feature['X'], 'y': feature['Y']},
				'distance': length.get(feature['Structure_'].split('\\')[-1], 10)
			}

	f1, f2, l1, l2 = list(all_data.keys())[:2][0], list(all_data.keys())[:2][1], list(all_data.keys())[-2:][0], list(all_data.keys())[-2:][1]
	dic1, dic2 = {}, {}
	dic1['first'] = {
		'coordinates': {
			'x': all_data[f1]['coordinates']['x'] - (all_data[f2]['coordinates']['x'] - all_data[f1]['coordinates']['x']),
			'y': all_data[f1]['coordinates']['y'] - (all_data[f2]['coordinates']['y'] - all_data[f1]['coordinates']['y'])
		},
		'distance': all_data[f1]['distance']
	}
	dic2['last'] = {
		'coordinates': {
			'x': all_data[l2]['coordinates']['x'] - (all_data[l1]['coordinates']['x'] - all_data[l2]['coordinates']['x']),
			'y': all_data[l2]['coordinates']['y'] - (all_data[l1]['coordinates']['y'] - all_data[l2]['coordinates']['y'])
		},
		'distance': all_data[f2]['distance']
	}
	all_data = {**dic1, **all_data, **dic2}

	def find_xy(xy_1, xy_2, angle, distance):
		vector1 = np.array([xy_2[0] - xy_1[0], xy_2[1] - xy_1[1]])
		unit_vector1 = vector1 / np.linalg.norm(vector1)

		unit_vector2 = np.array([
			unit_vector1[0] * math.cos(angle) - unit_vector1[1] * math.sin(angle),
			unit_vector1[0] * math.sin(angle) + unit_vector1[1] * math.cos(angle)
		])

		vector2 = unit_vector2 * distance
		x, y = xy_1[0] + vector2[0], xy_1[1] + vector2[1]
		return (x, y), (xy_1[0] - (x - xy_1[0]), xy_1[1] - (y - xy_1[1]))

	trio = []
	for key in all_data.keys():
		trio.append(key)
		if len(trio) != 3: continue
		xy1 = (all_data[trio[0]]['coordinates']['x'], all_data[trio[0]]['coordinates']['y'])
		xy2 = (all_data[trio[1]]['coordinates']['x'], all_data[trio[1]]['coordinates']['y'])
		xy3 = (all_data[trio[2]]['coordinates']['x'], all_data[trio[2]]['coordinates']['y'])
		v1 = np.array([xy2[0] - xy1[0], xy2[1] - xy1[1]])
		v2 = np.array([xy3[0] - xy2[0], xy3[1] - xy2[1]])

		theta = np.arccos(np.dot(v1, v2) / (np.linalg.norm(v1) * np.linalg.norm(v2)))
		degree = np.degrees(theta) if np.cross(v1, v2) < 0 else -np.degrees(theta)
		degree = 0 if np.allclose(v1, v2, atol=1e-6) else degree
		all_data[trio[1]]['angle'] = degree * 10 / 9

		y_axis = v1 / np.linalg.norm(v1)
		x_axis = np.array([-y_axis[1], y_axis[0]])

		d1, d2 = find_xy(xy2, xy3, math.radians(90 + degree / 2), all_data[trio[1]]['distance'] / 2)
		k1, k2 = find_xy(d1, xy2, math.radians(90), all_data[trio[1]]['distance'] / 2)
		k3, k4 = find_xy(d2, xy2, math.radians(90), all_data[trio[1]]['distance'] / 2)

		for i, point in enumerate([k1, k2, k3, k4], start=1):
			new_point = np.dot(np.array([x_axis, y_axis]).T, np.array([point[0] - xy2[0], point[1] - xy2[1]]))
			if new_point[0] > 0 > new_point[1]:
				label = 'k1'
			elif new_point[0] > 0 and new_point[1] > 0:
				label = 'k2'
			elif new_point[0] < 0 < new_point[1]:
				label = 'k3'
			else:
				label = 'k4'
			all_data[trio[1]][label] = {'x': point[0], 'y': point[1]}
		trio.pop(0)
	del all_data['first']
	del all_data['last']

	polygons = []
	points = []
	labels = []
	line = []

	for key, value in all_data.items():
		polygon = Polygon([
			(value['k1']['x'], value['k1']['y']),
			(value['k2']['x'], value['k2']['y']),
			(value['k3']['x'], value['k3']['y']),
			(value['k4']['x'], value['k4']['y'])
		])
		polygons.append(polygon)

		points.append(Point(value['k1']['x'], value['k1']['y']))
		labels.append('k1')
		points.append(Point(value['k2']['x'], value['k2']['y']))
		labels.append('k2')
		points.append(Point(value['k3']['x'], value['k3']['y']))
		labels.append('k3')
		points.append(Point(value['k4']['x'], value['k4']['y']))
		labels.append('k4')

		line.append((value['coordinates']['x'], value['coordinates']['y']))

	crs = layer.crs().authid()
	print(layer.crs())
	print(crs)
	polygons_gdf = gpd.GeoDataFrame(geometry=polygons, crs=crs)
	points_gdf = gpd.GeoDataFrame({'label': labels, 'geometry': points}, crs=crs)
	line_gdf = gpd.GeoDataFrame(geometry=[LineString(line)], crs=crs)

	def remove_layer(name):
		layers = QgsProject.instance().mapLayersByName(name)
		if layers:
			for l in layers:
				QgsProject.instance().removeMapLayer(l)

	remove_layer('Polygons')
	remove_layer('Points')
	remove_layer('Line')

	polygons_layer = QgsVectorLayer(polygons_gdf.to_json(), "Polygons", "ogr")
	QgsProject.instance().addMapLayer(polygons_layer)
	points_layer = QgsVectorLayer(points_gdf.to_json(), "Points", "ogr")
	QgsProject.instance().addMapLayer(points_layer)
	line_layer = QgsVectorLayer(line_gdf.to_json(), "Line", "ogr")
	QgsProject.instance().addMapLayer(line_layer)

	if save:
		polygons_gdf.to_file(shp_path + "/polygons.shp")
		points_gdf.to_file(shp_path + "/points.shp")
		line_gdf.to_file(shp_path + "/line.shp")


class CornerViewer:
	def __init__(self, iface):
		self.iface = iface
		self.plugin_dir = os.path.dirname(__file__)
		locale = QSettings().value('locale/userLocale')[0:2]
		locale_path = os.path.join(self.plugin_dir, 'i18n', 'CornerViewer_{}.qm'.format(locale))
		if os.path.exists(locale_path):
			self.translator = QTranslator()
			self.translator.load(locale_path)
			QCoreApplication.installTranslator(self.translator)
		self.actions = []
		self.menu = self.tr(u'&Corner Viewer')

	def tr(self, message):
		return QCoreApplication.translate('CornerViewer', message)

	def add_action(self, icon_path, text, callback, enabled_flag=True, add_to_menu=True, add_to_toolbar=True, status_tip=None, whats_this=None, parent=None):
		icon = QIcon(icon_path)
		action = QAction(icon, text, parent)
		action.triggered.connect(callback)
		action.setEnabled(enabled_flag)
		if status_tip is not None:
			action.setStatusTip(status_tip)
		if whats_this is not None:
			action.setWhatsThis(whats_this)
		if add_to_toolbar:
			self.iface.addToolBarIcon(action)
		if add_to_menu:
			self.iface.addPluginToMenu(self.menu, action)
		self.actions.append(action)
		return action

	def initGui(self):
		icon_path = ':/plugins/corner_viewer/icon.png'
		self.add_action(icon_path, text=self.tr(u'That is it...'), callback=self.run, parent=self.iface.mainWindow())

	def unload(self):
		for action in self.actions:
			self.iface.removePluginMenu(self.tr(u'&Corner Viewer'), action)
			self.iface.removeToolBarIcon(action)

	def run(self):
		self.dlg = CornerViewerDialog()
		self.dlg.buttonBox.accepted.connect(self.accept)
		self.dlg.buttonBox.rejected.connect(self.reject)
		self.dlg.show()

	def accept(self):
		inputs = self.dlg.get_inputs()
		excel = inputs['excel']
		layer = inputs['layer']
		shp_path = inputs['shp']
		save = inputs['save']
		self.dlg.accept()
		process_data(excel, layer, shp_path, save)

	def reject(self):
		self.dlg.reject()
